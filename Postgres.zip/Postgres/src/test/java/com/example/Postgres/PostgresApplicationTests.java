package com.example.Postgres;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PostgresApplicationTests {

	@Test
	void contextLoads() {
	}

}
